import java.util.ArrayList;
import java.util.List;

public class ArbolBinario {
    int dato;
    ArbolBinario iz;
    ArbolBinario der;

    public ArbolBinario(int dato) {
        this.dato = dato;
        iz = null;
        der = null;
    }

    public ArbolBinario(int dato, ArbolBinario iz, ArbolBinario der) {
        this.dato = dato;
        this.iz = iz;
        this.der = der;
    }

    public void preOrden() {
        System.out.print(this.dato + " ");
        if (iz != null) iz.preOrden();
        if (der != null) der.preOrden();
    }

    public void inOrden() {
        if (iz != null) iz.inOrden();
        System.out.print(this.dato + " ");
        if (der != null) der.inOrden();
    }

    public void posOrden() {
        if (iz != null) iz.posOrden();
        if (der != null) der.posOrden();
        System.out.print(this.dato + " ");
    }

    public int altura() {
        return altura(this);
    }

    private int altura(ArbolBinario raiz) {
        if (raiz == null) {
            return -1;
        }
        return 1 + Math.max(altura(raiz.iz), altura(raiz.der));
    }

    public int size() {
        return size(this);
    }

    private int size(ArbolBinario raiz) {
        if (raiz == null) {
            return 0;
        }
        return 1 + size(raiz.iz) + size(raiz.der);
    }

    public void tree() {
        tree(this, "");
    }

    private void tree(ArbolBinario raiz, String tab) {
        if (raiz != null) {
            System.out.println(tab + "->" + raiz.dato);
            tree(raiz.iz, tab + "  |");
            tree(raiz.der, tab + "  ");
        }
    }

    //metodo para encontrar la altura
    public List<Integer> nodosAltura(int altura) {
        List<Integer> valor = new ArrayList<>();
        obtenerAltura(this, 1, altura, valor);
        return valor;
    }

    //obtiene los datos para obtener la altura
    private void obtenerAltura(ArbolBinario raiz, int nivelActual, int alturaDeseada, List<Integer> valores) {
        if (raiz == null) {
            return;
        }

        if (nivelActual == alturaDeseada) {
            valores.add(raiz.dato);
        } else {
            obtenerAltura(raiz.iz, nivelActual + 1, alturaDeseada, valores);
            obtenerAltura(raiz.der, nivelActual + 1, alturaDeseada, valores);
        }
    }
}