public class Main {
    public static void main(String[] args) {
        Arbol arbol = new Arbol();

        arbol.agregarDato(20);
        arbol.agregarDato(50);
        arbol.agregarDato(10);
        arbol.agregarDato(90);
        arbol.agregarDato(30);
        arbol.agregarDato(100);
        arbol.agregarDato(60);


        arbol.recorrerInorden();
        int numeroNodos= arbol.contarNodos();
        System.out.println("el numero de nodos es "+numeroNodos);

    }
}