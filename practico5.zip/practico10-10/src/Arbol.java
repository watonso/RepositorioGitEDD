public class Arbol {
    Nodo raiz;

    public Arbol() {
        this.raiz = null;
    }

    public void agregarDato(int valor){
        raiz=insertarNodo(raiz,valor);
    }

    public Nodo insertarNodo(Nodo nodo, int dato){
        if (nodo == null) {
            nodo = new Nodo(dato);
            return nodo;
        }

        if (dato < nodo.getDato()) {
            nodo.setIzquierda(insertarNodo(nodo.getIzquierda(), dato));
        } else if (dato > nodo.getDato()) {
            nodo.setDerecha(insertarNodo(nodo.getDerecha(), dato));
        }

        return nodo;
    }

    public int contarNodos() {
        return contarNodosArbol(raiz);
    }

    private int contarNodosArbol(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }

        return 1 + contarNodosArbol(nodo.getIzquierda()) + contarNodosArbol(nodo.getDerecha());
    }

    public void recorrerInorden(){
        recorrerInordenRec(raiz);
    }

    private void recorrerInordenRec(Nodo nodo){
        if(nodo!=null){
            recorrerInordenRec(nodo.izquierda);
            System.out.println(nodo.dato+"");
            recorrerInordenRec(nodo.derecha);
        }
    }

}
