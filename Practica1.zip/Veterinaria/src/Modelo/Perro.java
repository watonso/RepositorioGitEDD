package Modelo;

import java.util.Date;

public class Perro extends Datos{
    public Perro(String animal, String nombreDueno, String nombre, String color, int edad, String fecha) {
        super(animal, nombreDueno, nombre, color, edad, fecha);
    }
}
