package Controlador;

import Modelo.Datos;

import java.util.ArrayList;
import java.util.Date;

public class ControladorVeterinaria {

    private final ArrayList<Datos> guardaAnimal;
    private ArrayList<Datos> altaAnimal;


    private ControladorVeterinaria(){
        guardaAnimal= new ArrayList<>();
        altaAnimal= new ArrayList<>();
    }

    public static ControladorVeterinaria instance = null;

    public static ControladorVeterinaria getInstance(){
        if(instance== null){
            instance=new ControladorVeterinaria();
        }
        return instance;
    }

    public void guardaAnimal (String animal,String nombreDueno,String nombre,String color,int edad,String fecha){
        Datos newDatos= new Datos(animal,nombreDueno,nombre,color,edad,fecha);
        guardaAnimal.add(newDatos);
    }


    public String[][] listaPaciente(){
        String[][] listadoPacientes= new String[guardaAnimal.size()][6];
        int i=0;
        for (Datos dato : guardaAnimal){
            listadoPacientes[i][0]=dato.getAnimal();
            listadoPacientes[i][1]=dato.getNombreDueno();
            listadoPacientes[i][2]=dato.getNombre();
            listadoPacientes[i][3]=dato.getColor();
            listadoPacientes[i][4]=String.valueOf(dato.getEdad());
            listadoPacientes[i][5]=dato.getFecha();
            i++;
        }
        return listadoPacientes;
    }

    public String[][] listaPacienteAlta(){
        String[][] listadoPacientesAlta= new String[altaAnimal.size()][6];
        int i=0;
        for (Datos dato : altaAnimal){
            listadoPacientesAlta[i][0]=dato.getAnimal();
            listadoPacientesAlta[i][1]=dato.getNombreDueno();
            listadoPacientesAlta[i][2]=dato.getNombre();
            listadoPacientesAlta[i][3]=dato.getColor();
            listadoPacientesAlta[i][4]=String.valueOf(dato.getEdad());
            listadoPacientesAlta[i][5]=dato.getFecha();
            i++;
        }
        return listadoPacientesAlta;
    }

    public boolean eliminarPacientePorNombre(String nombre) {
        for (Datos paciente : guardaAnimal) {
            if (paciente.getNombre().equalsIgnoreCase(nombre)) {
                guardaAnimal.remove(paciente);
                altaAnimal.add(paciente);
                return true;
            }
        }
        return false;
    }

}