public class Lista {

    Nodo cabeza;

    public  Lista (){
        this.cabeza=null;
    }

    public void agregarElemento(int dato) {
        Nodo nuevoNodo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo temp = cabeza;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo;
        }
    }

    public void imprimirLista() {
        Nodo temp = cabeza;
        while (temp != null) {
            System.out.print(temp.dato + " ");
            temp = temp.siguiente;
        }
        System.out.println();
    }

    public boolean esPalindromo() {
        if (cabeza == null) {
            return true; // Una lista vacía es un palíndromo.
        }

        // Paso 1: Divide la lista en dos mitades.
        Nodo mitad1 = cabeza;
        Nodo mitad2 = cabeza;
        Nodo previoMitad1 = null;

        while (mitad2 != null && mitad2.siguiente != null) {
            previoMitad1 = mitad1;
            mitad1 = mitad1.siguiente;
            mitad2 = mitad2.siguiente.siguiente;
        }

        // Si la lista tiene un número impar de elementos, la mitad2 se adelanta en uno.
        if (mitad2 != null) {
            mitad1 = mitad1.siguiente;
        }

        // Paso 2: Invierte la segunda mitad.
        Nodo previo = null;
        Nodo actual = mitad1;
        Nodo siguiente = null;

        while (actual != null) {
            siguiente = actual.siguiente;
            actual.siguiente = previo;
            previo = actual;
            actual = siguiente;
        }

        mitad1 = previo;

        // Paso 3: Compara las dos mitades.
        Nodo p1 = cabeza;
        Nodo p2 = mitad1;

        while (p1 != null && p2 != null) {
            if (p1.dato != p2.dato) {
                return false;
            }
            p1 = p1.siguiente;
            p2 = p2.siguiente;
        }

        return true;
    }


}
