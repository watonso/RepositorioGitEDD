import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner tcl= new Scanner(System.in);
        Lista lista = new Lista();
        int dato;

        System.out.println("ingrese 4 numeros");
        for (int i=1;i<=4;i++){
            dato=tcl.nextInt();
            lista.agregarElemento(dato);
        }

        lista.imprimirLista();
        boolean respuesta = lista.esPalindromo();
        System.out.println(respuesta);
    }
}