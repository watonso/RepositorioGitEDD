public class Main {
    public static void main(String[] args) {
        MaxHeap maxHeap = new MaxHeap();

        int[] numeros = {4, 1, 8, 9};

        for (int numero : numeros) {
            maxHeap.insert(numero);
            System.out.println("Añadiendo " + numero + " al MaxHeap:");
            maxHeap.printHeap();
        }

        System.out.println("\nLista Maxheap después de agregar elementos uno por uno:");
        maxHeap.printHeap();
        System.out.println("\nÁrbol Maxheap después de agregar elementos uno por uno:");
        maxHeap.imprimirMaxHeap();
    }

}