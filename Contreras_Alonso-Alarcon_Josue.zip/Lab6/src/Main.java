public class Main {
    public static void main(String[] args) {

        Abb a = new Abb();
        a.Insertar(10);
        a.Insertar(-8);
        a.Insertar(12);
        a.Insertar(4);
        a.Insertar(-7);

        System.out.println("el arbol es");
        a.Imprimir();

        System.out.println("¿existe comptemento?");
        System.out.println(a.Complemento(8));    // Retorna True, ya que existe el -8 en el árbol
        a.Eliminar(-8);
        System.out.println("¿existe comptemento?");
        System.out.println(a.Complemento(8));    // Retorna False, ya que se quitó el -8 en el árbol
    }
}
