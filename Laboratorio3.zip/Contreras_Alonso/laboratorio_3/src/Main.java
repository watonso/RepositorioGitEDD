import java.util.Collections;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        ListaEnlazada lista = new ListaEnlazada();
        Random random= new Random();

        // Agregar 10 elementos a la lista
        for (int i = 1; i <= 10; i++) {
            int numeroAleatorio=random.nextInt(100)+1;
            lista.agregarElemento(numeroAleatorio);
        }

        System.out.println("lista original");
        // Imprimir la lista
        lista.imprimirLista();

        System.out.println("Lista ordenada");
        //ordena la lista de mayor a menor
        lista.listaOrdenada();
        //imprime la lisa ordenada la lista
        lista.imprimirLista();



    }
}