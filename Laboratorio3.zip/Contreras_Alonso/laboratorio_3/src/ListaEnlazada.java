public class ListaEnlazada {
    Nodo cabeza;

    public ListaEnlazada() {
        this.cabeza = null;
    }

    public void agregarElemento(int dato) {
        Nodo nuevoNodo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo temp = cabeza;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo;
        }
    }

    public void imprimirLista() {
        Nodo temp = cabeza;
        while (temp != null) {
            System.out.print(temp.dato + " ");
            temp = temp.siguiente;
        }
        System.out.println();
    }

    public void listaOrdenada() {
        Nodo nodoActual = cabeza;
        while (nodoActual != null) {
            Nodo nodoMenor = nodoActual;
            Nodo nodoTemp = nodoActual.siguiente;

            while (nodoTemp != null) {
                if (nodoTemp.dato < nodoMenor.dato) {
                    nodoMenor = nodoTemp;
                }
                nodoTemp = nodoTemp.siguiente;
            }

            int temp = nodoActual.dato;
            nodoActual.dato = nodoMenor.dato;
            nodoMenor.dato = temp;

            nodoActual = nodoActual.siguiente;
        }
    }

}
