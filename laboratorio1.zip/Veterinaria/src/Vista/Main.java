package Vista;

import Controlador.ControladorVeterinaria;
import Modelo.Conejo;
import Modelo.Datos;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws ParseException {
        Scanner tcl = new Scanner(System.in);
        Date fechaActual= new Date();
        String usuario;
        String clave;

        System.out.println("ingrese tipo de usuario");
        usuario=tcl.next();

        while(usuario.equalsIgnoreCase("vet")){
            System.out.println("Igrese clave");
            clave=tcl.next();
            if (clave.equalsIgnoreCase("1234")){
                menuOpciones();
            }else {
                System.out.println("clave incorrecta");
            }
        }

        while (usuario.equalsIgnoreCase("dueno")){
            System.out.println("ingrese clave");
            clave=tcl.next();
            if (clave.equalsIgnoreCase("0000")){
                agregarMascota();
            }else{
                System.out.println("clave incorrecta");
            }
        }


    }

    public static void listaPaciente() {
        String[][] listaPacientes = ControladorVeterinaria.getInstance().listaPaciente();
        if (listaPacientes.length > 0) {
            System.out.printf("%-12s%-12s%-12s%-12s%-12s%-12s%n", "Tipo:", "Dueño:", "Nombre:", "Color:", "Edad:", "Fecha:");
            System.out.println("--------------------------------------------------------------------");
            for (String[] line : listaPacientes) {
                System.out.printf("%-12s%-12s%-12s%-12s%-12s%-12s%n", line[0], line[1], line[2], line[3], line[4], line[5]);
            }
        } else {
            System.out.println("no existen pacientes");
        }
    }

    public static void listaPacienteAlta() {
        String[][] listaPacientesAlta = ControladorVeterinaria.getInstance().listaPacienteAlta();
        if (listaPacientesAlta.length > 0) {
            System.out.printf("%-12s%-12s%-12s%-12s%-12s%-12s%n", "Tipo:", "Dueño:", "Nombre:", "Color:", "Edad:", "Fecha:");
            System.out.println("--------------------------------------------------------------------");
            for (String[] line : listaPacientesAlta) {
                System.out.printf("%-12s%-12s%-12s%-12s%-12s%-12s%n", line[0], line[1], line[2], line[3], line[4], line[5]);
            }
        } else {
            System.out.println("no existen pacientes");
        }
    }



    public static void eliminarPaciente() {
        Scanner tcl = new Scanner(System.in);
        System.out.println("Ingrese el nombre del paciente a eliminar: ");
        String nombrePaciente = tcl.next();

        if (ControladorVeterinaria.getInstance().eliminarPacientePorNombre(nombrePaciente)) {
            System.out.println("Paciente eliminado correctamente");
        } else {
            System.out.println("No se encontro paciente con ese nombre");
        }
    }

    public static void menuOpciones() throws ParseException {
        Date fechaActual= new Date();
        Scanner tcl = new Scanner(System.in);
        int opcion;

        do{
            System.out.println("[1]Agregar animal");
            System.out.println("[2]Eliminar animal");
            System.out.println("[3]Listar animales");
            System.out.println("[4]Listar pacientes Alta");
            System.out.println("[5]Salir");
            opcion = tcl.nextInt();
            switch (opcion) {
                case 1 -> agregarMascota();
                case 2 -> eliminarPaciente();
                case 3 -> listaPaciente();
                case 4 -> listaPacienteAlta();
            }
        }while (opcion!=5);
    }

    public static void agregarMascota() throws ParseException {
        Date fechaActual= new Date();
        Scanner tcl = new Scanner(System.in);

        System.out.println("ingrese el tipo de animal");
        String animal = tcl.next();
        System.out.println("Ingrese el nombre del dueño");
        String nombreDueno = tcl.next();
        System.out.println("Ingrese el nombre de la mascota");
        String nombre = tcl.next();
        System.out.println("Ingrese el color del animal");
        String color = tcl.next();
        System.out.println("ingrese la edad del animal");
        int edad = tcl.nextInt();
        System.out.println("Ingrese la fecha de nacimiento");
        String fechaString = tcl.next();

        Date fecha= new SimpleDateFormat("dd/MM/yyyy").parse(fechaString);
        fechaActual= new SimpleDateFormat("dd/MM/yyyy").parse(fechaString);

        //la idea es que compare con la fecha de hoy
        while (fechaActual.equals(fechaString)){
            System.out.println("ingrese fecha valida");
            fechaString=tcl.next();
        }
        ControladorVeterinaria.getInstance().guardaAnimal(animal, nombreDueno, nombre, color, edad, fechaString);
    }

}

