package Modelo;

import java.util.Date;

public class Datos {
    private String animal;
    private String nombreDueno;
    private String nombre;
    private String color;
    private int edad;
    private String fecha;


    public Datos(String animal, String nombreDueno, String nombre, String color, int edad, String fecha) {
        this.nombreDueno = nombreDueno;
        this.nombre = nombre;
        this.color = color;
        this.edad = edad;
        this.fecha = fecha;
        this.animal=animal;
    }

    public String getNombreDueno() {
        return nombreDueno;
    }

    public void setNombreDueno(String nombreDueno) {
        this.nombreDueno = nombreDueno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getAnimal() {
        return animal;
    }

    public void setAnimal(String animal) {
        this.animal = animal;
    }
}
