package Modelo;

import java.util.Date;

public class Gato extends Datos{
    public Gato(String animal, String nombreDueno, String nombre, String color, int edad, String fecha) {
        super(animal, nombreDueno, nombre, color, edad, fecha);
    }
}