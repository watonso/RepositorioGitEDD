package Modelo;

import java.util.Date;

public class Conejo extends Datos{
    public Conejo(String animal, String nombreDueno, String nombre, String color, int edad, String fecha) {
        super(animal, nombreDueno, nombre, color, edad, fecha);
    }
}
