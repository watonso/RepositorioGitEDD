public class Main {
    public static void main(String[] args) {
        Arbol arbol = new Arbol();

        arbol.agregarDato(20);
        arbol.agregarDato(50);
        arbol.agregarDato(10);
        arbol.agregarDato(43);
        arbol.agregarDato(79);
        

        int contadorDeHojas=arbol.contarHojas();
        System.out.println("la cantidad de hojas que tiene son: "+ contadorDeHojas);


    }
}