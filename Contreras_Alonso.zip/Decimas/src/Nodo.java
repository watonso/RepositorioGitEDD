public class Nodo {
    int dato;
    Nodo izqierda;
    Nodo derecha;

    public Nodo (int dato){
        this.dato=dato;
        this.izqierda=null;
        this.derecha=null;
    }

    public int getDato() {
        return dato;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }

    public Nodo getIzqierda() {
        return izqierda;
    }

    public void setIzqierda(Nodo izqierda) {
        this.izqierda = izqierda;
    }

    public Nodo getDerecha() {
        return derecha;
    }

    public void setDerecha(Nodo derecha) {
        this.derecha = derecha;
    }
}
