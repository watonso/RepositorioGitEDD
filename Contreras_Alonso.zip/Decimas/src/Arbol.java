import java.util.ArrayList;
import java.util.List;

public class Arbol {
    Nodo raiz;
    List<Arbol> hijos;

    public Arbol (){
        this.raiz=null;
        this.hijos = new ArrayList<>();
    }

    public void agregarDato(int valor){
        raiz=insertarNodo(raiz,valor);
    }

    public Nodo insertarNodo(Nodo nodo, int dato){
        if (nodo == null) {
            nodo = new Nodo(dato);
            return nodo;
        }

        if (dato < nodo.getDato()) {
            nodo.setIzqierda(insertarNodo(nodo.getIzqierda(), dato));
        } else if (dato > nodo.getDato()) {
            nodo.setDerecha(insertarNodo(nodo.getDerecha(), dato));
        }

        return nodo;
    }

    public int contarHojas() {
        return contarHojas(raiz);
    }

    private int contarHojas(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }

        if (nodo.getIzqierda() == null && nodo.getDerecha() == null) {
            return 1;
        }

        int hojasIzquierda = contarHojas(nodo.getIzqierda());
        int hojasDerecha = contarHojas(nodo.getDerecha());

        return hojasIzquierda + hojasDerecha;
    }



}
