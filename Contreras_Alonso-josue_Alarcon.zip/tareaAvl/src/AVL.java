public class AVL { //Clase que implementa un arbol AVL para almacenar las palabras y las listas de paginas (índice alfabético)
    private NodoIndex raiz;

    public AVL() {
        raiz = null;
    }


    public void insert(String newPalabra, int newPage) {
        raiz = insertNode(raiz, newPalabra, newPage);
    }

    private NodoIndex insertNode(NodoIndex nodo, String nuevaPalabra, int NroDePage) {
        if (nodo == null) {
            return new NodoIndex(nuevaPalabra);
        }

        int comparativa = nuevaPalabra.compareTo(nodo.palabraNodo);

        if (comparativa < 0) {
            nodo.hijoIzq = insertNode(nodo.hijoIzq, nuevaPalabra, NroDePage);
        } else {
            if (comparativa > 0) {
                nodo.hijoDer = insertNode(nodo.hijoDer, nuevaPalabra, NroDePage);
            } else {
                nodo.pageList.insertar(NroDePage);
                return nodo;
            }
        }
        //Esta parte se encarga de mantener en equilibrio el árbol AVL
        int balance = getBalance(nodo);

        if (balance > 1 && nuevaPalabra.compareTo(nodo.hijoIzq.palabraNodo) < 0) {
            return rightRotacion(nodo);
        }

        if (balance < -1 && nuevaPalabra.compareTo(nodo.hijoDer.palabraNodo) > 0) {
            return leftRotacion(nodo);
        }

        if (balance > 1 && nuevaPalabra.compareTo(nodo.hijoDer.palabraNodo) > 0) {
            nodo.hijoIzq = leftRotacion(nodo.hijoIzq);
            return rightRotacion(nodo);
        }

        if (balance < -1 && nuevaPalabra.compareTo(nodo.hijoDer.palabraNodo) < 0) {
            nodo.hijoDer = rightRotacion(nodo.hijoDer);
            return leftRotacion(nodo);
        }

        return nodo;
    }

    private int getHeight(NodoIndex node) { //Calcula la altura de un nodo dado de forma recursiva
        if (node == null) {
            return 0;
        }
        return 1 + Math.max(getHeight(node.hijoIzq), getHeight(node.hijoIzq));
    }

    private int getBalance(NodoIndex node) { //Calcula el factor de equilibrio de un nodo dado
        if (node == null) {
            return 0;
        }
        return getHeight(node.hijoIzq) - getHeight(node.hijoDer);
    }

    private NodoIndex rightRotacion(NodoIndex y) { //Realiza la rotación a la derecha
        NodoIndex C = y.hijoIzq;
        NodoIndex D = C.hijoDer;

        C.hijoDer = y;
        y.hijoIzq = D;
        return C;
    }

    private NodoIndex leftRotacion(NodoIndex x) { //Realiza la rotación a la izquierda
        NodoIndex A = x.hijoDer;
        NodoIndex B = A.hijoIzq;

        A.hijoIzq = x;
        x.hijoDer = B;
        return A;
    }

    public void printIndex() { //Método recursivo
        printIndex(raiz);
    }

    private void printIndex(NodoIndex node) { //Imprime las palabras en orden alfabético (inorden)
        if (node != null) {
            printIndex(node.hijoIzq);
            System.out.println(node.palabraNodo + " " + node.pageList.toString());
            printIndex(node.hijoDer);
        }
    }

    public PageList search(String palabraBuscar) { //Busca una palabra específica en el índice alfabético
        NodoIndex result = searchNode(raiz, palabraBuscar);
        if (result != null) {
            return result.pageList;
        } else {
            return null;
        }
    }

    private NodoIndex searchNode(NodoIndex node, String palabraBuscar) { //Busca en el AVL el nodo que contenga dicha palabra
        while (node != null) {
            int compara = palabraBuscar.compareTo(node.palabraNodo);
            if (compara < 0) {
                node = node.hijoIzq;
            } else {
                if (compara > 0) {
                    node = node.hijoDer;
                } else {
                    return node;
                }
            }
        }
        return null;
    }
}
