import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Alfabetica index = new Alfabetica();
        String nombrefila = "documento.txt";
        parseDocumento(nombrefila, index);
        index.printIndex();

        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("\n");
        System.out.print("Ingrese la palabra a buscar: ");
        String keyword = sc.next();
        PageList searchResult = index.buscaPalabra(keyword);
        System.out.println();

        if (searchResult != null) {
            System.out.println("Palabra clave a buscar: " + keyword);
            System.out.println("Páginas en las que se encuentra la palabra clave: " + searchResult);
        } else {
            System.out.println("La palabra pasada por parámetro no se encuentra en documento");
        }
    }

    public static void parseDocumento(String filename, Alfabetica index) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            int page = 1;
            while ((line = br.readLine()) != null) {
                if (line.contains("|")) {
                    page++;
                }
                String[] words = line.split("\\\\");
                for (int i = 1; i<words.length; i=i+2) {
                    index.insert(words[i], page);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}