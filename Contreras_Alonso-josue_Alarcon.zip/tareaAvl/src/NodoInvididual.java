public class NodoInvididual { //Clase que almacena las repeticiones de una palabra en una pagina
    int pagina;
    int repeticiones;
    NodoInvididual siguiente;

    public NodoInvididual(int Nropagina) {
        this.pagina = Nropagina;
        this.repeticiones = 1;
        this.siguiente = null;
    }
}
