public class PageList { //Almacena las paginas en las que se encuentra una palabra
    NodoInvididual head;

    public void insertar(int NumeroPage) {
        if (head == null) {
            head = new NodoInvididual(NumeroPage);
        } else {
            NodoInvididual busqueda = head;
            while (busqueda.siguiente != null && busqueda.pagina != NumeroPage) {
                busqueda = busqueda.siguiente;
            }
            if (busqueda.pagina == NumeroPage) {
                busqueda.repeticiones++;
            } else {
                busqueda.siguiente = new NodoInvididual(NumeroPage);
            }
        }
    }

    public String toString() { // Convierte la lista de paginas en un String
        StringBuilder cadena = new StringBuilder();
        NodoInvididual recorrer = head;
        while (recorrer != null) {
            cadena.append(recorrer.pagina);

            if (recorrer.repeticiones > 1) {
                cadena.append("(").append(recorrer.repeticiones).append(")");
            }
            cadena.append(", ");
            recorrer = recorrer.siguiente;
        }
        String convertirCadena = cadena.toString();

        if (convertirCadena.length() > 2) {
            convertirCadena = convertirCadena.substring(0, convertirCadena.length() - 2);
        }
        return convertirCadena;
    }
}