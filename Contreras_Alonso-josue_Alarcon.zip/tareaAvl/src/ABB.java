public class ABB {
    private String word;
    private int[] index;

    public ABB(String word, int[] index) {
        this.word = word;
        this.index = index;
    }

    public String getWord() {
        return word;
    }

    public int[] getIndex() {
        return index;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public void setIndex(int[] index) {
        this.index = index;
    }

    @Override
    public String toString() {
        String str = word + ": ";
        for (int i = 0; i < index.length; i++) {
            str += index[i] + " ";
        }
        return str;
    }
}
