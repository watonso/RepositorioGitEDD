public class IndexWord {
    String pIndiceAlfabetico;
    PageList pageList;

    public IndexWord(String pIndice) {
        this.pIndiceAlfabetico = pIndice;
        this.pageList = new PageList();
    }

    public String toString() {
        return pIndiceAlfabetico + " " + pageList.toString();
    }
}
