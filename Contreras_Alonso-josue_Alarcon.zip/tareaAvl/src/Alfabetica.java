public class Alfabetica {
    ListaIndex head;

    public void insert(String palabInserta, int pagAso) { //Método que inserta una palabra y su página asociada en el índice
        if (head == null) {
            // Se crea nuevo nodo con la palabra y la página asociada (primer nodo)
            head = new ListaIndex(palabInserta);
            head.getWord().pageList.insertar(pagAso);
        } else {
            //Se realiza busqueda para encontrar ubicación adecuada para insertar dicha palabra alfabéticamente
            ListaIndex curr = head;
            ListaIndex prev = null;
            while (curr != null && palabInserta.compareTo(curr.getWord().pIndiceAlfabetico) > 0) {
                prev = curr;
                curr = curr.sucesor;
            }

            if (curr == null) {
                //Se inserta el nuevo nodo después del nodo "prev"
                prev.sucesor = new ListaIndex(palabInserta);
                prev.sucesor.getWord().pageList.insertar(pagAso);

            } else {
                if (palabInserta.equals(curr.getWord().pIndiceAlfabetico)) {
                    curr.getWord().pageList.insertar(pagAso); //Se inserta la página asociada a la palabra existente
                } else {
                    //Se inserta el nuevo nodo antes del nodo "curr"
                    ListaIndex newIndex = new ListaIndex(palabInserta);
                    newIndex.getWord().pageList.insertar(pagAso);

                    if (prev == null) {
                        // "curr" es el primer nodo (o la cabeza de la lista)
                        newIndex.sucesor = head;
                        head = newIndex;
                    } else {
                        //Se establece la referencia del nodo "prev" al nuevo nodo
                        prev.sucesor = newIndex;
                        newIndex.sucesor = curr;
                    }
                }
            }
        }
    }

    public void printIndex() { //Imprime el índice en consola
        ListaIndex curr = head;
        while (curr != null) {
            System.out.println(curr.getWord().toString());
            curr = curr.sucesor;
        }
    }

    public PageList buscaPalabra(String palabraABus) { //Busca una palabra en el índice y devuelve la lista de páginas asociadas
        ListaIndex curr = head;
        while (curr != null) {
            if (curr.getWord().pIndiceAlfabetico.equalsIgnoreCase(palabraABus)) {
                return curr.getWord().pageList;
            }
            curr = curr.sucesor;
        }
        return null;
    }
}
