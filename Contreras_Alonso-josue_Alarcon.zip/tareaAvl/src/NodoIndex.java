public class NodoIndex { //Nodo del arbol AVL que almacenara las palabras y las listas de paginas
    String palabraNodo;
    NodoIndex hijoIzq, hijoDer;
    PageList pageList;

    public NodoIndex(String palabrita) {
        this.palabraNodo = palabrita;
        this.hijoIzq = null;
        this.hijoDer = null;
        this.pageList = new PageList();
    }
}
