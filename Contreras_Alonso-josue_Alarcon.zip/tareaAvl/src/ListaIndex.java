public class ListaIndex { //Clase que representa una palabra del índice alfabético y
    // y la lista de páginas asociadas a la misma
    IndexWord palabrita;
    ListaIndex sucesor;

    public ListaIndex(String palabra) {
        this.palabrita = new IndexWord(palabra);
        this.sucesor = null;
    }

    public IndexWord getWord() {
        return palabrita;
    }
}
