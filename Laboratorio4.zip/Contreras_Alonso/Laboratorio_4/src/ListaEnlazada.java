public class ListaEnlazada {
    Nodo cabeza;
    int tamano=0;

    public ListaEnlazada() {
        this.cabeza = null;
    }

    public void agregarElemento(int dato) {
        Nodo nuevoNodo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo temp = cabeza;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo;
        }
        tamano++;
    }

    public void imprimirLista() {
        Nodo temp = cabeza;
        while (temp != null) {
            System.out.print(temp.dato + " ");
            temp = temp.siguiente;
        }
        System.out.println();
    }

    public int calcularPromedio() {

        if (tamano == 0) {
            return 0;
        }

        int suma = 0;
        Nodo actual = cabeza;
        while (actual != null) {
            suma += actual.dato;
            actual = actual.siguiente;
        }

        return suma / tamano;
    }

    public void listaOrdenada() {
        Nodo nodoActual = cabeza;
        while (nodoActual != null) {
            Nodo nodoMenor = nodoActual;
            Nodo nodoTemp = nodoActual.siguiente;

            while (nodoTemp != null) {
                if (nodoTemp.dato < nodoMenor.dato) {
                    nodoMenor = nodoTemp;
                }
                nodoTemp = nodoTemp.siguiente;
            }

            int temp = nodoActual.dato;
            nodoActual.dato = nodoMenor.dato;
            nodoMenor.dato = temp;

            nodoActual = nodoActual.siguiente;
        }
    }

}
