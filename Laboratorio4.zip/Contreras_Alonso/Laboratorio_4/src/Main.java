import java.util.List;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        Random random= new Random();
        ListaEnlazada lista1 = new ListaEnlazada();
        ListaEnlazada lista2 = new ListaEnlazada();
        ListaEnlazada lista3 = new ListaEnlazada();

        // Agregar 10 elementos a la lista
        for (int i = 1; i <= 10; i++) {
            int numeroAleatorio=random.nextInt(100)+1;
            lista1.agregarElemento(numeroAleatorio);
        }

        for (int i = 1; i <= 10; i++) {
            int numeroAleatorio=random.nextInt(100)+1;
            lista2.agregarElemento(numeroAleatorio);
        }

        // Imprimir la lista
        System.out.println("Primera lista");
        lista1.imprimirLista();
        System.out.println("Segunda lista");
        lista2.imprimirLista();

        int promedio1 = lista1.calcularPromedio();
        int promedio2 = lista2.calcularPromedio();

        System.out.println("Promedio primera lista");
        System.out.println(promedio1);
        System.out.println("Promedio segunda lista");
        System.out.println(promedio2);

        Nodo actual=lista1.cabeza;
        while (actual!=null){
            if (actual.dato>promedio1){
                lista3.agregarElemento(actual.dato);
            }
            actual=actual.siguiente;
        }
        actual = lista2.cabeza;
        while (actual!=null){
            if (actual.dato>promedio2){
                lista3.agregarElemento(actual.dato);
            }
            actual=actual.siguiente;
        }
        
        lista3.listaOrdenada();
        lista3.imprimirLista();


    }
}