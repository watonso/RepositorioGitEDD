public class Nodo {
    int id;
    int dato;


    public Nodo(int valor, int dato) {
        this.id = valor;
        this.dato = dato;
    }

    public int getValor() {
        return id;
    }

    public void setValor(int valor) {
        this.id = valor;
    }

    public int getDato() {
        return dato;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }
}
