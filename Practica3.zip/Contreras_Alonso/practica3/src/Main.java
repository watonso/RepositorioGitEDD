import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random random= new Random();
        ArrayList<Nodo> listaNodo= new ArrayList<>();

        for (int i=0;i<10;i++){
            int numeroAleatorio=random.nextInt(100)+1;
            listaNodo.add(new Nodo(i,numeroAleatorio));
        }

        for(Nodo nodo : listaNodo){
            System.out.println("Id:"+ nodo.getValor() + "Numero: " + nodo.getDato());
        }

        System.out.println("----------------------------------");

        Collections.sort(listaNodo, (a,b)->Integer.compare(a.dato,b.dato));

        for(Nodo nodo : listaNodo){
            System.out.println("Id:"+ nodo.getValor() + "Numero: " + nodo.getDato());
        }
    }
}